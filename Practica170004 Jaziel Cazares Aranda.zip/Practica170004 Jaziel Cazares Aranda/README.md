# Instalación

El proyecto se generó en la versión 9 de Angular CLI.
Antes de instalar es necesario ejecutar `npm install`

## Ejecución

Ejecutar `ng serve` para ejecutar la aplicación.
_Ejecutar_ `ng serve -o` para ejecutar la aplicación y se abre en el navegador automaticamente.
